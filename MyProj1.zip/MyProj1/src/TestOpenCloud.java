import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import org.mcavallo.opencloud.Cloud;
import org.mcavallo.opencloud.Tag;

public class TestOpenCloud {

    public String[] WORDS;
    public static Map<String,StringList> finalOne;
    public static int max_font_value;
    public TestOpenCloud(Map<String,StringList> finalOne)
    {
    	this.finalOne= finalOne;
    	 String[] finalWords = new String[101];
         int cnt=0;
         for (Entry<String, StringList> entry : finalOne.entrySet())
         {
       	  String word1=entry.getKey();
       	  if(word1!="")
       	  finalWords[cnt]=entry.getKey().toLowerCase(); 
       	  cnt++;
       	  if(cnt==1)
       		  max_font_value=entry.getValue().getCount();
         }
         WORDS=finalWords;
    }

    protected void initUI() {
        JFrame frame = new JFrame("Trending Now !!!");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        final JPanel panel = new JPanel(new WrapLayout());
        Cloud cloud = new Cloud();
        final Random random = new Random();
        for (String s : WORDS) {
            for (int i = random.nextInt(100); i > 0; i--) {
                cloud.addTag(s);
               Tag tag = new Tag();
            }
            
        }
        for (Tag tag : cloud.tags()) {
            final JLabel label = new JLabel(tag.getName());
            label.setOpaque(false);
           // int sixe_font = finalOne.get(label.getText()).getCount()/max_font_value;
            final Random r=new Random();
            Color c=new Color(r.nextInt(256),r.nextInt(256),r.nextInt(256),r.nextInt(256));
            label.setForeground(c);
            label.setFont(label.getFont().deriveFont((float) tag.getWeight() * 10));
           // Font font = new Font("Verdana", Font.BOLD, sixe_font*20);
            //	label.setFont(font);
            tag.getWeight();
            panel.add(label);
            label.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                   JFrame jf=new JFrame(label.getText());
                   JPanel jpr= new JPanel(new FlowLayout(FlowLayout.LEFT));
                   Font font = new Font("Verdana", Font.BOLD, 20);
                   
                   Set<String> URLISTS=getURLLinks(label.getText());
                   for(String link:URLISTS)
                   {
                	   JButton links =new JButton(link);
                	   links.setContentAreaFilled(false);
                	   links.setBorderPainted(false);
                	   links.setFocusPainted(false);
                	   links.setOpaque(true);
                	   links.setFont(font);
                	   jpr.add(links);
                	   links.addMouseListener(new MouseAdapter(){
                		   public void mouseClicked(MouseEvent e){
                			   
                			   if (Desktop.isDesktopSupported()){
                			   Desktop desktop = Desktop.getDesktop();

                			   URI uri = null;
							try {
								uri = new URI(links.getText());
								
							} catch (URISyntaxException e2) {
								// TODO Auto-generated catch block
								e2.printStackTrace();
							}
                               try {
                            	   super.mouseEntered(e);
								desktop.browse(uri);
								links.setForeground(Color.MAGENTA);
							} catch (Exception e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
                		   }}
                		   
                		   public void mouseEntered(MouseEvent e)
                		   {
                			   super.mouseEntered(e);
                			   links.setForeground(Color.RED);
                		   }
                		   
                		   public void mouseExited(MouseEvent e)
                		   {
                			   super.mouseExited(e);
                			   links.setForeground(Color.BLACK);
                		   }
                	   });
                   }
                   
                  // g.setFont(font);
                jf.setBackground(Color.BLACK);
                jf.setSize(new Dimension(600,800));
                jf.setVisible(true);
                jf.getDefaultCloseOperation();
                jf.add(jpr);
                }

				private Set<String> getURLLinks(String word) {
					// TODO Auto-generated method stub
					//System.out.println(word);
					
					Set<String> urlLinks = new HashSet<String>();
					if(finalOne.containsKey(word))
						urlLinks=finalOne.get(word).getURLset();
					else
						urlLinks.add("www.news.ngoogle.com");
					//for(String link:urlLinks)
						//System.out.println(link);
				
		        	return urlLinks;
					
				}
            });
        }
        
        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        frame.add(scrollPane);
        frame.setSize(500, 550);
        frame.setVisible(true);
        Timer t = new Timer(1000, new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                final JLabel label = new JLabel(WORDS[random.nextInt(WORDS.length)]);
                label.setOpaque(false);
                int fontSize=0;
                //if (currentWord==null)
                	fontSize = random.nextInt(20) + 8;
                //else
                //	fontSize = curWord_count/max_font_value;
                final Random r=new Random();
                Color c=new Color(r.nextInt(256),r.nextInt(256),r.nextInt(256),r.nextInt(256));
                label.setForeground(c);
                label.setFont(label.getFont().deriveFont((float) fontSize));
                panel.add(label);
                panel.revalidate();
                panel.repaint();
            }
        });
        t.start();
    }

    public class WrapLayout extends FlowLayout {
        private Dimension preferredLayoutSize;

        /**
         * Constructs a new <code>WrapLayout</code> with a left alignment and a default 5-unit horizontal and vertical gap.
         */
        public WrapLayout() {
            super();
        }

        /**
         * Constructs a new <code>FlowLayout</code> with the specified alignment and a default 5-unit horizontal and vertical gap. The value
         * of the alignment argument must be one of <code>WrapLayout</code>, <code>WrapLayout</code>, or <code>WrapLayout</code>.
         * 
         * @param align
         *            the alignment value
         */
        public WrapLayout(int align) {
            super(align);
        }

        /**
         * Creates a new flow layout manager with the indicated alignment and the indicated horizontal and vertical gaps.
         * <p>
         * The value of the alignment argument must be one of <code>WrapLayout</code>, <code>WrapLayout</code>, or <code>WrapLayout</code>.
         * 
         * @param align
         *            the alignment value
         * @param hgap
         *            the horizontal gap between components
         * @param vgap
         *            the vertical gap between components
         */
        public WrapLayout(int align, int hgap, int vgap) {
            super(align, hgap, vgap);
        }

        /**
         * Returns the preferred dimensions for this layout given the <i>visible</i> components in the specified target container.
         * 
         * @param target
         *            the component which needs to be laid out
         * @return the preferred dimensions to lay out the subcomponents of the specified container
         */
        @Override
        public Dimension preferredLayoutSize(Container target) {
            return layoutSize(target, true);
        }

        /**
         * Returns the minimum dimensions needed to layout the <i>visible</i> components contained in the specified target container.
         * 
         * @param target
         *            the component which needs to be laid out
         * @return the minimum dimensions to lay out the subcomponents of the specified container
         */
        @Override
        public Dimension minimumLayoutSize(Container target) {
            Dimension minimum = layoutSize(target, false);
            minimum.width -= getHgap() + 1;
            return minimum;
        }

        /**
         * Returns the minimum or preferred dimension needed to layout the target container.
         * 
         * @param target
         *            target to get layout size for
         * @param preferred
         *            should preferred size be calculated
         * @return the dimension to layout the target container
         */
        private Dimension layoutSize(Container target, boolean preferred) {
            synchronized (target.getTreeLock()) {
                // Each row must fit with the width allocated to the containter.
                // When the container width = 0, the preferred width of the container
                // has not yet been calculated so lets ask for the maximum.

                int targetWidth = target.getSize().width;

                if (targetWidth == 0) {
                    targetWidth = Integer.MAX_VALUE;
                }

                int hgap = getHgap();
                int vgap = getVgap();
                Insets insets = target.getInsets();
                int horizontalInsetsAndGap = insets.left + insets.right + hgap * 2;
                int maxWidth = targetWidth - horizontalInsetsAndGap;

                // Fit components into the allowed width

                Dimension dim = new Dimension(0, 0);
                int rowWidth = 0;
                int rowHeight = 0;

                int nmembers = target.getComponentCount();

                for (int i = 0; i < nmembers; i++) {
                    Component m = target.getComponent(i);

                    if (m.isVisible()) {
                        Dimension d = preferred ? m.getPreferredSize() : m.getMinimumSize();

                        // Can't add the component to current row. Start a new row.

                        if (rowWidth + d.width > maxWidth) {
                            addRow(dim, rowWidth, rowHeight);
                            rowWidth = 0;
                            rowHeight = 0;
                        }

                        // Add a horizontal gap for all components after the first

                        if (rowWidth != 0) {
                            rowWidth += hgap;
                        }

                        rowWidth += d.width;
                        rowHeight = Math.max(rowHeight, d.height);
                    }
                }

                addRow(dim, rowWidth, rowHeight);

                dim.width += horizontalInsetsAndGap;
                dim.height += insets.top + insets.bottom + vgap * 2;

                // When using a scroll pane or the DecoratedLookAndFeel we need to
                // make sure the preferred size is less than the size of the
                // target container so shrinking the container size works
                // correctly. Removing the horizontal gap is an easy way to do this.

                Container scrollPane = SwingUtilities.getAncestorOfClass(JScrollPane.class, target);

                if (scrollPane != null) {
                    dim.width -= hgap + 1;
                }

                return dim;
            }
        }

        /*
         *  A new row has been completed. Use the dimensions of this row
         *  to update the preferred size for the container.
         *
         *  @param dim update the width and height when appropriate
         *  @param rowWidth the width of the row to add
         *  @param rowHeight the height of the row to add
         */
        private void addRow(Dimension dim, int rowWidth, int rowHeight) {
            dim.width = Math.max(dim.width, rowWidth);

            if (dim.height > 0) {
                dim.height += getVgap();
            }

            dim.height += rowHeight;
        }
        
       
    }
}
