import java.lang.*;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.SortedSet;
import java.util.TreeSet;

public class SortOutput {
	public static boolean ASC = true;
	public static boolean DESC = false;
	
	public Map<String,StringList> sortNprint(DataHolder dh)
	{
		Map<String, StringList> sortedMapAsc = sortByComparator(dh.check, ASC);
		Map<String,StringList> finaleOne =printMap(sortedMapAsc);
		return finaleOne;
		
	}
	
	
	 private static Map<String, StringList> sortByComparator(Map<String, StringList> unsortMap, final boolean order)
	    {

	        List<Entry<String, StringList>> list = new LinkedList<>(unsortMap.entrySet());

	        // Sorting the list based on values
	        Collections.sort(list, new Comparator<Entry<String, StringList>>()
	        {
	            @Override
	            public int compare(Entry<String, StringList> o1, Entry<String, StringList> o2)
	            {
	                if (order)
	                {
	                    return o1.getValue().compareTo(o2.getValue());
	                }
	                else
	                {
	                    return o2.getValue().compareTo(o1.getValue());

	                }
	            }
	        });

	        // Maintaining insertion order with the help of LinkedList
	        Map<String, StringList> sortedMap = new LinkedHashMap<>();
	        for (Entry<String, StringList> entry : list)
	        {
	            sortedMap.put(entry.getKey(), entry.getValue());
	        }

	        return sortedMap;
	    }
	  public static Map<String,StringList> printMap(Map<String, StringList> map)
	    { int count =0;
	      int linkcount=0;
	      Map<String,StringList> finaleResult = new HashMap<String,StringList>();
	        for (Entry<String, StringList> entry : map.entrySet())
	        {
	        	if(count > 100)
	        		break;
	        	count+=1;
	        	Set<String> URLinks = new HashSet<String>();
	        	URLinks = entry.getValue().getURLset();
	        	linkcount=entry.getValue().getCount();
	        	finaleResult.put(entry.getKey().toLowerCase(), entry.getValue());
	        	//System.out.println();
	        	//for(String t : URLinks)
	        	//{
	        		//System.out.println("Key : " + entry.getKey() + " and it's Count : " + linkcount);	
	        	
	        }
			return finaleResult;
	    }

}
