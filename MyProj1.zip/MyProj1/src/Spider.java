import java.util.*;
import java.util.Map.Entry;


public class Spider
{
  public int current_depth=0;
  private Map<String,Integer> pagesVisited = new LinkedHashMap<String,Integer>();
  private Map<String,Integer> pagesToVisit = new LinkedHashMap<String,Integer>();
  DataHolder dh = new DataHolder();
  
  /**
   * Our main launching point for the Spider's functionality. Internally it creates spider legs
   * that make an HTTP request and parse the response (the web page).
   * 
   * @param url
   *            - The starting point of the spider.
   * @param Page_depth
   *            - The maximum depth from the root.
   */
  public void search(String url, int MAX_SCRAWL_DEPTH)
  {
	  List<String> intm = new LinkedList<String>();
	  String prevUrl = url;
	  while(this.current_depth < MAX_SCRAWL_DEPTH)
      {
          String currentUrl;
          
          int depth=0;
          Crawler leg = new Crawler();
         
          
          if(this.pagesToVisit.isEmpty())
          {
              currentUrl = url;
              this.pagesVisited.put(url,depth);
              this.pagesToVisit.put(url,depth);
          }
          else
          {
              currentUrl = this.nextUrl(prevUrl);
              prevUrl = currentUrl;
          }
          depth = pagesToVisit.get(currentUrl);
          this.current_depth=depth;
          if(depth > MAX_SCRAWL_DEPTH)
          {
        	  break;
          }
          else
          {
          boolean isitok =leg.crawl(currentUrl); 
          intm.addAll(leg.getLinks());
          if(isitok)
          leg.performAnalysis(currentUrl,dh);
          
          
          for(String t:intm)
	      {
	    	if (!pagesToVisit.containsKey(t))
	    	{
	    		if(t!="")
	    		{
	    			if(!pagesVisited.containsKey(t))
	    				pagesToVisit.put(t,depth+1);
	    		      // System.out.println(t);
	    		      // System.out.println(depth +1);
	    		}
	    	}
          }
          }
      //System.out.println("\n**Done** Visited " + this.pagesVisited.size() + " web page(s)");
      
      
      }
	  SortOutput so=new SortOutput();
      Map<String,StringList> finaleOne = so.sortNprint(dh);
      String[] finalWords = new String[101];
      int cnt=0;
      for (Entry<String, StringList> entry : finaleOne.entrySet())
      {
    	  String word1=entry.getKey();
    	  if(word1!="")
    	  finalWords[cnt]=entry.getKey(); 
    	  cnt++;
      }
      
      TestOpenCloud toc = new TestOpenCloud(finaleOne);
      toc.initUI();
	 
  }
  /**
   * Returns the next URL to visit (in the order that they were found). We also do a check to make
   * sure this method doesn't return a URL that has already been visited.
   * 
   * @return
   */
  private String nextUrl(String url)
  {
      String nextUrl;
      pagesToVisit.remove(url);
      Map.Entry<String,Integer> entry=pagesToVisit.entrySet().iterator().next();
      
     do
      {          
    	nextUrl = entry.getKey();	
      } while(this.pagesVisited.containsKey(nextUrl));
      this.pagesVisited.put(nextUrl,0);
      return nextUrl;
  }
}