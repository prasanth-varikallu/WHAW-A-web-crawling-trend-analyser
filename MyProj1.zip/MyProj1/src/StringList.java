
import java.util.HashSet;

import java.util.Set;

public class StringList implements Comparable{

	private Integer count=0;
	private Set<String> URLset = new HashSet<String>();
	public Set<String> getURLset() {
		return URLset;
	}
	public void setURLset(Set<String> uRLset) {
		URLset = uRLset;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	
	 public int compareTo(Object arg0) {
	        StringList sl1=(StringList) arg0;
	        return (this.getCount() > sl1.getCount() ) ? -1: (this.getCount() < sl1.getCount() ) ? 1:0;
	    }  
}
