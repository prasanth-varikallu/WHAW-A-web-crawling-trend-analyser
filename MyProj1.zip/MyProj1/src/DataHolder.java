

import java.util.*;

public class DataHolder {
	
	Map<String,StringList> check = new HashMap<String,StringList>();
	}
