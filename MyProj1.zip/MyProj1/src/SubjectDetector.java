import java.lang.*;
import java.util.*;
import java.util.Map.Entry;

public class SubjectDetector {
	
	 Map<String, Integer> totalWordList = new HashMap<String, Integer>();
	 
	 public Map<String,Integer> AnalyzeText(String sit,String URL,DataHolder dh)
	 {
		 Map<String, Integer> WordFreq = new HashMap<String,Integer>();
		 Map<String, Integer> Highfreq = new HashMap<String,Integer>();
		 //String[] words = sit.split(" ");
		 String sit1=sit.replaceAll("[^a-zA-Z]", " ");
		 String[] words =sit1.replaceAll("\\w*\\d\\w*", "").trim().split(" ");
		 StopWords sw = new StopWords();
		 for (String w : words) {
		     
			 if(!sw.isStopWord(w))
			 {
			 Integer n = WordFreq.get(w);
		        n = (n == null) ? 1 : ++n;
		        WordFreq.put(w, n);
			 }
		    }
		 		 
		 Highfreq = sortByValues(WordFreq,URL,dh);
		 return Highfreq;
		 
	 }
	 
	 @SuppressWarnings("unchecked")
	public static <String extends Comparable,Integer extends Comparable> Map<String,Integer> sortByValues(Map<String,Integer> map,String url1,DataHolder dh){
		    List<Map.Entry<String,Integer>> entries = new LinkedList<Map.Entry<String,Integer>>(map.entrySet());
		    int count=0;
		  
		    Collections.sort(entries, new Comparator<Map.Entry<String,Integer>>() {

		        @Override
		        public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
		        		return o2.getValue().compareTo(o1.getValue());
		        }
		    });
	 

		    Map<String,Integer> sortedMap = new LinkedHashMap<String,Integer>();
		    
		    for(Map.Entry<String,Integer> entry: entries){
		    	if(count > 20)
		    		break;
		    	else
		    	{
		    		String word=entry.getKey();
		    		Integer Count=entry.getValue();
		    		sortedMap.put(word, Count);
		            count+=1;
		            //  System.out.println(word + ":" + Count);
		            int count2= ((java.lang.Integer) Count).intValue();
		            
		            Set<String> URLset1 ;
		    		if(dh.check.containsKey(word))	
		    		{
		    			StringList sl=dh.check.get(word);
		    			int count3 = sl.getCount().intValue();
		    			count3+=count2;		    			 		    			 
		    			sl.setCount(count3);  
		    			
		    			URLset1 =  (Set<String>) sl.getURLset();
		    			URLset1.add(url1);
		    			sl.setURLset((Set<java.lang.String>) URLset1);
		    			dh.check.put((java.lang.String) word,sl);
		    		} 
		    		else
		    		{
		    			StringList sl = new StringList();
		    			sl.setCount(1);
		    			sl.getURLset().add((java.lang.String) url1);
		    			dh.check.put((java.lang.String) word,sl);
		    			
		    		}
		    	}
		    }  
		    return sortedMap;

}}