import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Reflection;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
 
/**
 *
 * @web http://zoranpavlovic.blogspot.com/
 */
public class WebSpider extends Application {
 
       
    public static void main(String[] args) {
        launch(args);
    }
     
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("JavaFX 2 Crawl");
       
        BorderPane bp = new BorderPane();
        bp.setPadding(new Insets(10,50,50,50));
       
        //Adding HBox
        HBox hb = new HBox();
        hb.setPadding(new Insets(20,20,20,30));
       
        //Adding GridPane
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20,20,20,20));
        gridPane.setHgap(5);
        gridPane.setVgap(5);
        ColumnConstraints column = new ColumnConstraints(500);
        gridPane.getColumnConstraints().add(column);
       
       //Implementing Nodes for GridPane
        Label lblUrlName = new Label("Enter the URL to start ");
        final TextField txtUrlName = new TextField();
        txtUrlName.setMinSize(100,10);
        Label lblDepth = new Label("Enter Depth to crawl ");
        final TextField txtDepth = new TextField();
        
        //System.out.println(txURL);
        Button btnExplore = new Button("Explore");
        final Label lblMessage = new Label();
       
        //Adding Nodes to GridPane layout
        gridPane.add(lblUrlName, 0, 0);
        gridPane.add(txtUrlName, 0, 1);
        gridPane.add(lblDepth, 1, 0);
        gridPane.add(txtDepth, 1, 1);
        gridPane.add(btnExplore, 2, 1);
        gridPane.add(lblMessage, 1, 2);
       
               
        //Reflection for gridPane
        Reflection r = new Reflection();
        r.setFraction(0.7f);
        gridPane.setEffect(r);
       
        //DropShadow effect
        DropShadow dropShadow = new DropShadow();
        dropShadow.setOffsetX(5);
        dropShadow.setOffsetY(5);
       
        //Adding text and DropShadow effect to it
        Text text = new Text("What's Happening Around World(WHAW)");
        text.setFont(Font.font("Courier New", FontWeight.BOLD, 28));
        text.setEffect(dropShadow);
       
        //Adding text to HBox
        hb.getChildren().add(text);
                         
        //Add ID's to Nodes
        bp.setId("bp");
        gridPane.setId("root");
        btnExplore.setId("btnExplore");
        text.setId("text");
               
        //Action for btnLogin
        btnExplore.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent event) {
                	Spider spider = new Spider();
                	String textURL = txtUrlName.getText();
                    if (!(textURL.startsWith("http") || textURL.startsWith("https")))
                    	textURL = "http://"+textURL;
                    final String txURL = textURL;
                	spider.search(txURL,Integer.parseInt(txtDepth.getText()));
                }
                });
       
        //Add HBox and GridPane layout to BorderPane Layout
        bp.setTop(hb);
        bp.setCenter(gridPane);  
       
        //Adding BorderPane to the scene and loading CSS
        Scene scene = new Scene(bp);
        scene.getStylesheets().add(getClass().getClassLoader().getResource("WebSpider.css").toExternalForm());
        primaryStage.setScene(scene);
//          primaryStage.titleProperty().bind(
//                    scene.widthProperty().asString().
//                    concat(" : ").
//                    concat(scene.heightProperty().asString()));
        //primaryStage.setResizable(false);
        primaryStage.show();
    }
}